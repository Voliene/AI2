O:41:"Symfony\Component\AssetMapper\MappedAsset":10:{s:10:"sourcePath";s:60:"C:\Users\bieni\Desktop\AI2-lab\pogodynka\assets\bootstrap.js";s:10:"publicPath";s:53:"/assets/bootstrap-c423b8bbc1f9cae218c105ca8ca9f767.js";s:23:"publicPathWithoutDigest";s:20:"/assets/bootstrap.js";s:15:"publicExtension";s:2:"js";s:7:"content";s:210:"import { startStimulusApp } from '@symfony/stimulus-bundle';

const app = startStimulusApp();
// register any custom, 3rd party controllers here
// app.register('some_controller_name', SomeImportedController);
";s:6:"digest";s:32:"c423b8bbc1f9cae218c105ca8ca9f767";s:13:"isPredigested";b:0;s:55:" Symfony\Component\AssetMapper\MappedAsset dependencies";a:0:{}s:59:" Symfony\Component\AssetMapper\MappedAsset fileDependencies";a:0:{}s:11:"logicalPath";s:12:"bootstrap.js";}