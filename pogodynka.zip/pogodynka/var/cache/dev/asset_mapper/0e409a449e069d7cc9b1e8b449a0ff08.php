O:41:"Symfony\Component\AssetMapper\MappedAsset":10:{s:10:"sourcePath";s:54:"C:\Users\bieni\Desktop\AI2-lab\pogodynka\assets\app.js";s:10:"publicPath";s:47:"/assets/app-7ff2e9d8cfaf8e13e6c69b3eb02f8cf1.js";s:23:"publicPathWithoutDigest";s:14:"/assets/app.js";s:15:"publicExtension";s:2:"js";s:7:"content";s:292:"import './bootstrap.js';
/*
 * Welcome to your app's main JavaScript file!
 *
 * This file will be included onto the page via the importmap() Twig function,
 * which should already be in your base.html.twig.
 */
console.log('This log comes from assets/app.js - welcome to AssetMapper! 🎉')
";s:6:"digest";s:32:"7ff2e9d8cfaf8e13e6c69b3eb02f8cf1";s:13:"isPredigested";b:0;s:55:" Symfony\Component\AssetMapper\MappedAsset dependencies";a:1:{i:0;O:45:"Symfony\Component\AssetMapper\AssetDependency":3:{s:5:"asset";O:41:"Symfony\Component\AssetMapper\MappedAsset":10:{s:10:"sourcePath";s:60:"C:\Users\bieni\Desktop\AI2-lab\pogodynka\assets\bootstrap.js";s:10:"publicPath";s:53:"/assets/bootstrap-c423b8bbc1f9cae218c105ca8ca9f767.js";s:23:"publicPathWithoutDigest";s:20:"/assets/bootstrap.js";s:15:"publicExtension";s:2:"js";s:7:"content";s:210:"import { startStimulusApp } from '@symfony/stimulus-bundle';

const app = startStimulusApp();
// register any custom, 3rd party controllers here
// app.register('some_controller_name', SomeImportedController);
";s:6:"digest";s:32:"c423b8bbc1f9cae218c105ca8ca9f767";s:13:"isPredigested";b:0;s:55:" Symfony\Component\AssetMapper\MappedAsset dependencies";a:0:{}s:59:" Symfony\Component\AssetMapper\MappedAsset fileDependencies";a:0:{}s:11:"logicalPath";s:12:"bootstrap.js";}s:6:"isLazy";b:0;s:19:"isContentDependency";b:0;}}s:59:" Symfony\Component\AssetMapper\MappedAsset fileDependencies";a:0:{}s:11:"logicalPath";s:6:"app.js";}